import { useState } from 'react';
import { WalletBalance } from './WalletBalance';
import { QuickActions } from './QuickActions';
import { TransactionList } from './TransactionList';
import { CardManager } from './CardManager';
import { PaymentModal } from './PaymentModal';
import { toast } from '@/components/ui/use-toast';
import { Wallet, Bell, Settings, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';

const AppLayout = () => {
  const [balance] = useState(125000);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'send' | 'receive' | 'topup'>('send');
  const [cards, setCards] = useState([
    { id: '1', type: 'visa' as const, lastFour: '4532', expiryDate: '12/25', isDefault: true },
    { id: '2', type: 'mastercard' as const, lastFour: '8901', expiryDate: '08/26', isDefault: false }
  ]);
  const [transactions] = useState([
    { id: '1', type: 'receive' as const, amount: 25000, description: 'Salary Payment', date: '2024-01-15', status: 'completed' as const },
    { id: '2', type: 'send' as const, amount: 5000, description: 'Coffee Shop', date: '2024-01-14', status: 'completed' as const },
    { id: '3', type: 'mobile' as const, amount: 10000, description: 'MTN Top Up', date: '2024-01-13', status: 'pending' as const }
  ]);

  const handleQuickAction = (type: 'send' | 'receive' | 'topup') => {
    setModalType(type);
    setModalOpen(true);
  };

  const handlePayment = (data: any) => {
    toast({ title: 'Success', description: `${modalType} completed successfully!` });
  };

  const handleAddCard = () => {
    toast({ title: 'Add Card', description: 'Card addition feature coming soon!' });
  };

  const handleRemoveCard = (cardId: string) => {
    setCards(cards.filter(card => card.id !== cardId));
    toast({ title: 'Card Removed', description: 'Payment card removed successfully' });
  };

  const handleSetDefault = (cardId: string) => {
    setCards(cards.map(card => ({ ...card, isDefault: card.id === cardId })));
    toast({ title: 'Default Card Updated', description: 'Default payment card updated' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-white/20 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-purple-600 to-blue-600 p-2 rounded-lg">
                <Wallet className="text-white" size={24} />
              </div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                RwandaPay
              </h1>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm" className="text-gray-600">
                <Bell size={20} />
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600">
                <Settings size={20} />
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600 md:hidden">
                <Menu size={20} />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-8">
            <WalletBalance balance={balance} />
            <QuickActions
              onSendMoney={() => handleQuickAction('send')}
              onReceiveMoney={() => handleQuickAction('receive')}
              onAddCard={handleAddCard}
              onMobileMoney={() => handleQuickAction('topup')}
              onTopUp={() => handleQuickAction('topup')}
            />
            <TransactionList transactions={transactions} />
          </div>

          {/* Right Column */}
          <div className="space-y-8">
            <CardManager
              cards={cards}
              onAddCard={handleAddCard}
              onRemoveCard={handleRemoveCard}
              onSetDefault={handleSetDefault}
            />
          </div>
        </div>
      </main>

      <PaymentModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        type={modalType}
        onSubmit={handlePayment}
      />
    </div>
  );
};

export default AppLayout;