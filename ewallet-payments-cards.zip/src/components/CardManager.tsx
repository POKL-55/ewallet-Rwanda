import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Plus, Trash2 } from 'lucide-react';

interface PaymentCard {
  id: string;
  type: 'visa' | 'mastercard' | 'amex';
  lastFour: string;
  expiryDate: string;
  isDefault: boolean;
}

interface CardManagerProps {
  cards: PaymentCard[];
  onAddCard: () => void;
  onRemoveCard: (cardId: string) => void;
  onSetDefault: (cardId: string) => void;
}

export const CardManager = ({ cards, onAddCard, onRemoveCard, onSetDefault }: CardManagerProps) => {
  const getCardColor = (type: string) => {
    switch (type) {
      case 'visa': return 'bg-gradient-to-r from-blue-600 to-blue-800';
      case 'mastercard': return 'bg-gradient-to-r from-red-600 to-red-800';
      case 'amex': return 'bg-gradient-to-r from-green-600 to-green-800';
      default: return 'bg-gradient-to-r from-gray-600 to-gray-800';
    }
  };

  return (
    <Card className="shadow-lg border-0">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-gray-800">Payment Cards</CardTitle>
          <Button onClick={onAddCard} size="sm" className="bg-purple-600 hover:bg-purple-700">
            <Plus size={16} className="mr-1" />
            Add Card
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {cards.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <CreditCard size={48} className="mx-auto mb-4 opacity-50" />
            <p>No cards added yet</p>
            <p className="text-sm">Add your first payment card to get started</p>
          </div>
        ) : (
          cards.map((card) => (
            <div key={card.id} className={`${getCardColor(card.type)} rounded-lg p-4 text-white relative`}>
              {card.isDefault && (
                <Badge className="absolute top-2 right-2 bg-white text-gray-800">
                  Default
                </Badge>
              )}
              <div className="flex justify-between items-start mb-4">
                <div>
                  <p className="text-sm opacity-80">Card ending in</p>
                  <p className="text-xl font-bold">•••• {card.lastFour}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm opacity-80">Expires</p>
                  <p className="font-semibold">{card.expiryDate}</p>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <p className="text-sm font-medium uppercase">{card.type}</p>
                <div className="flex space-x-2">
                  {!card.isDefault && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => onSetDefault(card.id)}
                      className="text-white hover:bg-white/20 text-xs"
                    >
                      Set Default
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onRemoveCard(card.id)}
                    className="text-white hover:bg-white/20 p-1"
                  >
                    <Trash2 size={14} />
                  </Button>
                </div>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
};