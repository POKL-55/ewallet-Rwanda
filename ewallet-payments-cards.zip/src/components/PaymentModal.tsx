import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useState } from 'react';
import { CreditCard, Smartphone, Building } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'send' | 'receive' | 'topup';
  onSubmit: (data: any) => void;
}

export const PaymentModal = ({ isOpen, onClose, type, onSubmit }: PaymentModalProps) => {
  const [amount, setAmount] = useState('');
  const [recipient, setRecipient] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ amount: parseFloat(amount), recipient, paymentMethod, description });
    setAmount('');
    setRecipient('');
    setPaymentMethod('');
    setDescription('');
    onClose();
  };

  const getTitle = () => {
    switch (type) {
      case 'send': return 'Send Money';
      case 'receive': return 'Request Money';
      case 'topup': return 'Top Up Wallet';
      default: return 'Payment';
    }
  };

  const paymentMethods = [
    { value: 'mtn', label: 'MTN Mobile Money', icon: Smartphone },
    { value: 'airtel', label: 'Airtel Money', icon: Smartphone },
    { value: 'visa', label: 'Visa Card', icon: CreditCard },
    { value: 'mastercard', label: 'Mastercard', icon: CreditCard },
    { value: 'bank', label: 'Bank Transfer', icon: Building }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-gray-800">{getTitle()}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="amount">Amount (RWF)</Label>
            <Input
              id="amount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount"
              required
              className="text-lg"
            />
          </div>
          
          {type !== 'topup' && (
            <div>
              <Label htmlFor="recipient">{type === 'send' ? 'Recipient' : 'From'}</Label>
              <Input
                id="recipient"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                placeholder="Phone number or email"
                required
              />
            </div>
          )}

          <div>
            <Label>Payment Method</Label>
            <Select value={paymentMethod} onValueChange={setPaymentMethod} required>
              <SelectTrigger>
                <SelectValue placeholder="Select payment method" />
              </SelectTrigger>
              <SelectContent>
                {paymentMethods.map((method) => (
                  <SelectItem key={method.value} value={method.value}>
                    <div className="flex items-center space-x-2">
                      <method.icon size={16} />
                      <span>{method.label}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="description">Description (Optional)</Label>
            <Input
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What's this for?"
            />
          </div>

          <div className="flex space-x-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
              {getTitle()}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};