import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Send, Download, CreditCard, Smartphone, Plus } from 'lucide-react';

interface QuickActionsProps {
  onSendMoney: () => void;
  onReceiveMoney: () => void;
  onAddCard: () => void;
  onMobileMoney: () => void;
  onTopUp: () => void;
}

export const QuickActions = ({ 
  onSendMoney, 
  onReceiveMoney, 
  onAddCard, 
  onMobileMoney, 
  onTopUp 
}: QuickActionsProps) => {
  const actions = [
    { icon: Send, label: 'Send', onClick: onSendMoney, color: 'bg-blue-500 hover:bg-blue-600' },
    { icon: Download, label: 'Receive', onClick: onReceiveMoney, color: 'bg-green-500 hover:bg-green-600' },
    { icon: CreditCard, label: 'Add Card', onClick: onAddCard, color: 'bg-purple-500 hover:bg-purple-600' },
    { icon: Smartphone, label: 'Mobile Money', onClick: onMobileMoney, color: 'bg-orange-500 hover:bg-orange-600' },
    { icon: Plus, label: 'Top Up', onClick: onTopUp, color: 'bg-pink-500 hover:bg-pink-600' }
  ];

  return (
    <Card className="shadow-lg border-0">
      <CardContent className="p-6">
        <h3 className="font-semibold mb-4 text-gray-800">Quick Actions</h3>
        <div className="grid grid-cols-5 gap-3">
          {actions.map((action, index) => (
            <div key={index} className="flex flex-col items-center">
              <Button
                onClick={action.onClick}
                className={`${action.color} text-white rounded-full h-12 w-12 p-0 shadow-lg transform hover:scale-105 transition-all duration-200`}
              >
                <action.icon size={20} />
              </Button>
              <span className="text-xs mt-2 text-gray-600 font-medium">{action.label}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};