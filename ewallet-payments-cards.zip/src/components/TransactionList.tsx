import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowUpRight, ArrowDownLeft, CreditCard, Smartphone } from 'lucide-react';

interface Transaction {
  id: string;
  type: 'send' | 'receive' | 'card' | 'mobile';
  amount: number;
  description: string;
  date: string;
  status: 'completed' | 'pending' | 'failed';
}

interface TransactionListProps {
  transactions: Transaction[];
}

export const TransactionList = ({ transactions }: TransactionListProps) => {
  const getIcon = (type: string) => {
    switch (type) {
      case 'send': return <ArrowUpRight className="text-red-500" size={20} />;
      case 'receive': return <ArrowDownLeft className="text-green-500" size={20} />;
      case 'card': return <CreditCard className="text-blue-500" size={20} />;
      case 'mobile': return <Smartphone className="text-orange-500" size={20} />;
      default: return <ArrowUpRight size={20} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="shadow-lg border-0">
      <CardHeader>
        <CardTitle className="text-gray-800">Recent Transactions</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {transactions.map((transaction) => (
          <div key={transaction.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gray-100 rounded-full">
                {getIcon(transaction.type)}
              </div>
              <div>
                <p className="font-medium text-gray-900">{transaction.description}</p>
                <p className="text-sm text-gray-500">{transaction.date}</p>
              </div>
            </div>
            <div className="text-right">
              <p className={`font-semibold ${transaction.type === 'send' ? 'text-red-600' : 'text-green-600'}`}>
                {transaction.type === 'send' ? '-' : '+'}{transaction.amount.toLocaleString()} RWF
              </p>
              <Badge className={`${getStatusColor(transaction.status)} text-xs`}>
                {transaction.status}
              </Badge>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};