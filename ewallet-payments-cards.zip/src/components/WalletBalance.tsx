import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Eye, EyeOff } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

interface WalletBalanceProps {
  balance: number;
}

export const WalletBalance = ({ balance }: WalletBalanceProps) => {
  const [showBalance, setShowBalance] = useState(true);

  return (
    <Card className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 shadow-xl">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-medium opacity-90">Total Balance</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowBalance(!showBalance)}
            className="text-white hover:bg-white/20 p-1 h-8 w-8"
          >
            {showBalance ? <EyeOff size={16} /> : <Eye size={16} />}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold">
          {showBalance ? `${balance.toLocaleString()} RWF` : '••••••'}
        </div>
        <p className="text-sm opacity-80 mt-1">Available funds</p>
      </CardContent>
    </Card>
  );
};